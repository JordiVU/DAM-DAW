package ejemplofx.ejemplofx;

import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import model.Book;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    //TODO add @FXML variables

    //TODO add a static list with the information



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
            //TODO read file with books and add them to lvBooks

        //TODO listener for the listView


        //TODO initialize the choiceBox

        //TODO listener to the choiceBox



    }
    public void showOrderedBy(String order) {
        //TODO sort the list  in the order received

        //TODO show the list sorted

        }

    public void loadBooks() {
        //TODO read the file and fill the list books

       //TODO set the listView with the list books

    }

    public boolean anyEmptyField()
    {
        //TODO return if any of the textbox is empty

    }
    public void addBook(ActionEvent actionEvent) {
        //TODO add a new book to the list of books
        //TODO first you have to check the textFields. Any of them can't be empty.

            //TODO set the listview again with books to show the changes

        }


    public void writeMessage(String title, String message) {
    //TODO a function to show a new Alert with the title and  message provided

    }
    public void updateBook(ActionEvent actionEvent) {
        //TODO update a book in the list

        //TODO set the listview with books again to show the changes

    }

    public void deleteBook(ActionEvent actionEvent) {
        //TODO delete a book of the list

        //TODO set the listview with books again to show the changes

    }
    public static void WriteFile() {
    //TODO write en the file the list books in the same format

    }
}
